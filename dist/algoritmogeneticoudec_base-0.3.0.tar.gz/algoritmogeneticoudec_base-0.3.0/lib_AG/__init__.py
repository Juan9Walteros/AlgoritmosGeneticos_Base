# filepath: /Users/juanwalteros/Documents/Universidad/Algoritmos geneticos/AlgoritmoGeneticoUdeC_Base/lib_AG/__init__.py
from .Funciones import funcion_objetivo, crear_individuo, crear_poblacion